﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Wk.Api.Produtos.Domain.Entities;
using Wk.Api.Produtos.Domain.Interfaces.Repositories;
using Wk.Api.Produtos.Domain.Interfaces.Services;

namespace Wk.Api.Produtos.Domain.Services
{

    public class BaseServico<T> : IBaseServico<T> where T : BaseEntidade
    {
        protected readonly IBaseRepositorio<T> _repositorio;

        public BaseServico(IBaseRepositorio<T> repositorio)
        {
            _repositorio = repositorio;
        }

        #region Escrita
        public async Task Incluir(T entidade)
        {
            await IniciarTransaction();
            await _repositorio.Incluir(entidade);
            await SalvarMudancas();
        }

        public async Task IncluirLista(List<T> entidade)
        {
            await IniciarTransaction();
            await _repositorio.IncluirLista(entidade);
            await SalvarMudancas();
        }

        public async Task Alterar(T entidade)
        {
            await IniciarTransaction();
            _repositorio.Alterar(entidade);
            await SalvarMudancas();
        }
        public async Task AlterarLista(IEnumerable<T> entidades)
        {
            await IniciarTransaction();
            _repositorio.AlterarLista(entidades);
            await SalvarMudancas();
        }

        public async Task Excluir(object id)
        {
            await IniciarTransaction();
            await _repositorio.Excluir(id);
            await SalvarMudancas();
        }

        public async Task IniciarTransaction()
        {
            await _repositorio.IniciarTransaction();
        }

        public async Task SalvarMudancas()
        {
            await _repositorio.SalvarMudancas();
        }

        #endregion Escrita

        #region Leitura

        public virtual async Task<T> BuscarPorId(object id, string[] includes = default, bool tracking = false)
        {
            return await _repositorio.BuscarPorId(id, includes, tracking);
        }

        public async Task<T> BuscarComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false)
        {
            return await _repositorio.BuscarComPesquisa(expression, includes, tracking);
        }

        public IQueryable<T> Buscar(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false)
        {
            return _repositorio.Buscar(expression, includes, tracking);
        }

        public virtual async Task<IEnumerable<T>> BuscarTodos(string[] includes = default, bool tracking = false)
        {
            return await _repositorio.BuscarTodos(includes, tracking);
        }

        public async Task<IEnumerable<T>> BuscarTodosComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false)
        {
            return await _repositorio.BuscarTodosComPesquisa(expression, includes, tracking);
        }

        public async Task<IEnumerable<T>> BuscarPorSql(string query)
        {
            return await _repositorio.BuscarPorSql(query);
        }

        #endregion
    }
}
