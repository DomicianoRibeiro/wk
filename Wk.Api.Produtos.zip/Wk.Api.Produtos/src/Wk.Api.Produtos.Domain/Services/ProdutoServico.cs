﻿using Wk.Api.Produtos.Domain.Entities;
using Wk.Api.Produtos.Domain.Interfaces.Repositories;
using Wk.Api.Produtos.Domain.Interfaces.Services;

namespace Wk.Api.Produtos.Domain.Services
{
    public class ProdutoServico : BaseServico<Produto>, IProdutoServico
    {
        public ProdutoServico(IProdutoRepositorio ProdutoRepositorio) : base(ProdutoRepositorio)
        {
        }
    }
}
