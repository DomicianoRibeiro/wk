﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Wk.Api.Produtos.Domain.Entities;

public class Produto : BaseEntidade
{
    public int CategoriaId { get; set; }
    public string Nome { get; set; }
    public decimal Preco { get; set; }
    public decimal Peso { get; set; }
    public string Cor { get; set; }
    public string Modelo { get; set; }
    public string Marca { get; set; }

    [NotMapped]
    public Categoria Categoria { get; set; }
}
