﻿namespace Wk.Api.Produtos.Domain.Entities
{
    public abstract class BaseEntidade
    {
        public int Id { get; set; }
    }
}
