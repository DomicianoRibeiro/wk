﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Wk.Api.Produtos.Domain.Entities;

public class Categoria : BaseEntidade
{
    public string Descricao { get; set; }

    [NotMapped]
    public Produto Produto { get; set; }
}