﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Wk.Api.Produtos.Domain.Interfaces.Repositories
{
    public interface IBaseRepositorio<T> where T : class
    {
        Task IniciarTransaction();
        Task SalvarMudancas(bool commit = true);
        Task RollbackTransaction();
        Task Commit();

        #region Escrita
        Task<T> Incluir(T entidade);
        Task IncluirLista(List<T> entidade);
        T Alterar(T entidade);
        void AlterarLista(IEnumerable<T> entidades);
        Task<bool> Excluir(object id);
        Task<int> ExecutarQuery(string query);
        #endregion

        #region Leitura
        Task<T> BuscarPorId(object id, string[] includes = default, bool tracking = false);

        Task<T> BuscarComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false);

        IQueryable<T> Buscar(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false);

        Task<IEnumerable<T>> BuscarTodos(string[] includes = default, bool tracking = false);

        Task<IEnumerable<T>> BuscarTodosComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false);

        Task<IEnumerable<T>> BuscarPorSql(string query);
        #endregion
    }
}
