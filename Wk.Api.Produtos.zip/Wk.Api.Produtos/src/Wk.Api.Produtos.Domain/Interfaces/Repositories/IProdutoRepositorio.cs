﻿using Wk.Api.Produtos.Domain.Entities;

namespace Wk.Api.Produtos.Domain.Interfaces.Repositories
{
    public interface IProdutoRepositorio : IBaseRepositorio<Produto>
    {
    }
}
