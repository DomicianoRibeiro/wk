﻿using Wk.Api.Produtos.Domain.Entities;

namespace Wk.Api.Produtos.Domain.Interfaces.Services
{
    public interface IProdutoServico : IBaseServico<Produto>
    {
    }
}
