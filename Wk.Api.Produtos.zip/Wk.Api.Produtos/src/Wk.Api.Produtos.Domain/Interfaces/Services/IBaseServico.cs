﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Wk.Api.Produtos.Domain.Interfaces.Services
{
    public interface IBaseServico<T> where T : class
    {
        #region Escrita
        Task Incluir(T entidade);
        Task IncluirLista(List<T> entidade);
        Task Alterar(T entidade);
        Task AlterarLista(IEnumerable<T> entidades);
        Task Excluir(object id);
        Task IniciarTransaction();
        Task SalvarMudancas();
        #endregion

        #region Leitura
        Task<T> BuscarPorId(object id, string[] includes = default, bool tracking = false);

        Task<T> BuscarComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false);

        IQueryable<T> Buscar(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false);

        Task<IEnumerable<T>> BuscarTodos(string[] includes = default, bool tracking = false);

        Task<IEnumerable<T>> BuscarTodosComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false);

        Task<IEnumerable<T>> BuscarPorSql(string query);

        #endregion
    }
}
