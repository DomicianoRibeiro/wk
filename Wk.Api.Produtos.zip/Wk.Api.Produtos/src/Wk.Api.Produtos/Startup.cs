using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using MySql.Data.MySqlClient;
using Serilog;
using Serilog.Events;
using Serilog.Formatting.Compact;
using System;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;
using Wk.Api.Produtos.Filters;
using Wk.Api.Produtos.Infra.Data.Contexto;
using Wk.Api.Produtos.Infra.IoC;
using Wk.Api.Produtos.Middlewares;

namespace Wk.Api.Produtos
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup()
        {
            Configuration = SetarAppSettings();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            InjectorDependencies.Registrer(services);

            services.AddCors();

            ConfigurarSwagger(services);

            services.AddControllersWithViews(options =>
            {
                options.AllowEmptyInputInBodyModelBinding = true;
            });

            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            });

            ConfigurarBancoDeDados(services);
            ConfigurarLogs();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //global error handler
            app.UseMiddleware<ErrorHandlerMiddleware>();

            CultureInfo[] supportedCultures = new[] { new CultureInfo("pt-BR") };
            app.UseRequestLocalization(new RequestLocalizationOptions
            {
                DefaultRequestCulture = new RequestCulture(culture: "pt-BR", uiCulture: "pt-BR"),
                SupportedCultures = supportedCultures,
                SupportedUICultures = supportedCultures
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
                c.RoutePrefix = string.Empty;
            });

            app.UseCors(x => x
                .AllowAnyMethod()
                .AllowAnyHeader()
                .SetIsOriginAllowed(origin => true) 
                .AllowCredentials()); 

            app.UseHttpsRedirection();
            app.UseSerilogRequestLogging();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        private void ConfigurarLogs()
        {
#if DEBUG
            Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(Configuration)
            .CreateLogger();

            Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .WriteTo.File(
                  restrictedToMinimumLevel: LogEventLevel.Error,
                  formatter: new CompactJsonFormatter(),
                  path: "logs/log-error.json",
                  rollOnFileSizeLimit: true,
                  fileSizeLimitBytes: 10485760, // 10 MB
                  retainedFileCountLimit: 20
               )
            .WriteTo.File(
                restrictedToMinimumLevel: LogEventLevel.Warning,
                formatter: new CompactJsonFormatter(),
                path: "logs/log-warning.json",
                rollOnFileSizeLimit: true,
                fileSizeLimitBytes: 10485760, // 10 MB
                retainedFileCountLimit: 20
             )
             .WriteTo.File(
                restrictedToMinimumLevel: LogEventLevel.Fatal,
                formatter: new CompactJsonFormatter(),
                path: "logs/log-fatal.json",
                rollOnFileSizeLimit: true,
                fileSizeLimitBytes: 10485760, // 10 MB
                retainedFileCountLimit: 20
             )
            .CreateLogger();
#endif
        }

        private void ConfigurarBancoDeDados(IServiceCollection services)
        {
            services.AddDbContext<BaseContexto>
                ((serviceProvider, dbContextBuilder) =>
                {
                    MySqlConnectionStringBuilder connectionString = new()
                    {
                        SslMode = MySqlSslMode.Disabled,
                        Server = Configuration["DB_HOST_IP"],
                        Password = Configuration["DB_PASS"],
                        Database = Configuration["DB_NAME"],
                        Port = Convert.ToUInt32(Configuration["DB_HOST_PORT"]),
                        UserID = Configuration["DB_USER"]
                    };
                    connectionString.Pooling = false;
                    connectionString.AllowPublicKeyRetrieval = true;
                    connectionString.DefaultCommandTimeout = 240;
                    dbContextBuilder.UseMySQL(connectionString.ConnectionString);
                },
                ServiceLifetime.Scoped);
        }

        private static void ConfigurarSwagger(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "API",
                    Description = "",
                    Contact = new OpenApiContact
                    {
                        Name = "WkTechnology",
                        Email = string.Empty
                    }
                });
                c.OperationFilter<SwaggerJsonIgnoreFilter>();
            });
        }


        private static IConfiguration SetarAppSettings()
        {
            string envName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            configurationBuilder.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            if (!string.IsNullOrWhiteSpace(envName))
                configurationBuilder.AddJsonFile($"appsettings.{envName}.json", optional: true);
            configurationBuilder.AddEnvironmentVariables();
            return configurationBuilder.Build();
        }
    }
}