﻿using Microsoft.AspNetCore.Http;
using Serilog;
using System;
using System.Threading.Tasks;

namespace Wk.Api.Produtos.Middlewares
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;

        public ErrorHandlerMiddleware(
              RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Gera o log de todas requisição realizada
        /// </summary>
        /// <returns></returns>
        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (ArgumentException ex)
            {
                if (context.Response.HasStarted)
                    throw;

                await MenssagemErro400(context, ex);
            }
            catch (Exception error)
            {
                if (context.Response.HasStarted)
                    throw;

                await MenssagemErro500(context, error);
            }
        }

        private async Task MenssagemErro500(HttpContext context, Exception error)
        {
            Log.Error(error, error.Message);
            HttpResponse response = context.Response;
            response.ContentType = "application/json";
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            await response.WriteAsync("Erro interno. Por favor procure o suporte.");
        }

        private async Task MenssagemErro400(HttpContext context, Exception error)
        {
            HttpResponse response = context.Response;
            response.ContentType = "application/json";
            context.Response.StatusCode = StatusCodes.Status400BadRequest;
            await response.WriteAsync(error.Message);
        }
    }
}
