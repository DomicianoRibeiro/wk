using Microsoft.AspNetCore.Mvc;
using Wk.Api.Produtos.Domain.Entities;
using Wk.Api.Produtos.Domain.Interfaces.Services;

namespace Wk.Api.Produtos
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]

    public class ProdutoController : BaseController<Produto>
    {
        private readonly IProdutoServico _produtoServico;

        public ProdutoController(IProdutoServico produtoServico) : base(produtoServico)
        {
            _produtoServico = produtoServico;
        }
    }
}
