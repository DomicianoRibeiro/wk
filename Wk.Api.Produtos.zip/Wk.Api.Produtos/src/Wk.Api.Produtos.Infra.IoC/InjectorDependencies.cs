﻿using Microsoft.Extensions.DependencyInjection;
using Wk.Api.Produtos.Domain.Interfaces.Repositories;
using Wk.Api.Produtos.Domain.Interfaces.Services;
using Wk.Api.Produtos.Domain.Services;
using Wk.Api.Produtos.Infra.Data.Repositories;

namespace Wk.Api.Produtos.Infra.IoC
{
    public static class InjectorDependencies
    {
        public static void Registrer(IServiceCollection services)
        {
            //Domínio 
            services.AddScoped(typeof(IBaseServico<>), typeof(BaseServico<>));
            services.AddScoped<IProdutoServico, ProdutoServico>();

            //Repositorio
            services.AddScoped(typeof(IBaseRepositorio<>), typeof(BaseRepositorio<>));
            services.AddScoped<IProdutoRepositorio, ProdutoRepositorio>();
        }
    }
}
