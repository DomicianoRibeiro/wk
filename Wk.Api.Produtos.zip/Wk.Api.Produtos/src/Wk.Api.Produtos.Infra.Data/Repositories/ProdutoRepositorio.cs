﻿using Wk.Api.Produtos.Domain.Entities;
using Wk.Api.Produtos.Domain.Interfaces.Repositories;
using Wk.Api.Produtos.Infra.Data.Contexto;

namespace Wk.Api.Produtos.Infra.Data.Repositories
{
    public class ProdutoRepositorio : BaseRepositorio<Produto>, IProdutoRepositorio
    {
        public ProdutoRepositorio(BaseContexto context) : base(context)
        {
        }
    }
}
