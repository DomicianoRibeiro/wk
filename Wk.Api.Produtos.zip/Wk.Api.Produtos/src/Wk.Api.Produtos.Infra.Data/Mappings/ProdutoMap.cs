﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Wk.Api.Produtos.Domain.Entities;

namespace Wk.Api.Produtos.Infra.Data.Mappings
{
    public class ProdutoMap : IEntityTypeConfiguration<Produto>
    {
        public void Configure(EntityTypeBuilder<Produto> builder)
        {
            builder.ToTable("produto");

            builder.HasKey(s => s.Id);

            builder
            .Property(c => c.Id)
            .ValueGeneratedOnAdd()
            .IsRequired()
            .HasColumnName("produto_id");

            builder
            .Property(c => c.CategoriaId)
            .HasColumnName("categoria_id")
            .IsRequired();

            builder
            .Property(c => c.Nome)
            .HasColumnName("produto_nome")
            .IsRequired();

            builder
            .Property(c => c.Preco)
            .HasColumnName("produto_preco")
            .HasColumnType("decimal(16,2)")
            .IsRequired();

            builder
            .Property(c => c.Peso)
            .HasColumnName("produto_peso")
            .HasColumnType("decimal(16,2)")
            .IsRequired();

            builder
            .Property(c => c.Cor)
            .HasColumnName("produto_cor")
            .IsRequired();

            builder
            .Property(c => c.Modelo)
            .HasColumnName("produto_modelo")
            .IsRequired();

            builder
            .Property(c => c.Marca)
            .HasColumnName("produto_marca")
            .IsRequired();

            builder.HasOne(x => x.Categoria)
             .WithOne(x => x.Produto)
             .HasForeignKey<Produto>(x => x.CategoriaId)
             .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
