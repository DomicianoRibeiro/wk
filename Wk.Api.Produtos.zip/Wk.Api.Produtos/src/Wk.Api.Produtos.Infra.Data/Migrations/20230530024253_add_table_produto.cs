﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Wk.Api.Produtos.Infra.Data.Migrations
{
    /// <inheritdoc />
    public partial class add_table_produto : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySQL:Charset", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "produto",
                columns: table => new
                {
                    produto_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    categoria_id = table.Column<int>(type: "int", nullable: false),
                    produto_nome = table.Column<string>(type: "longtext", nullable: false),
                    produto_preco = table.Column<decimal>(type: "decimal(16,2)", nullable: false),
                    produto_peso = table.Column<decimal>(type: "decimal(16,2)", nullable: false),
                    produto_cor = table.Column<string>(type: "longtext", nullable: false),
                    produto_modelo = table.Column<string>(type: "longtext", nullable: false),
                    produto_marca = table.Column<string>(type: "longtext", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_produto", x => x.produto_id);
                    table.ForeignKey(
                        name: "FK_produto_categoria_categoria_id",
                        column: x => x.categoria_id,
                        principalTable: "categoria",
                        principalColumn: "categoria_id",
                        onDelete: ReferentialAction.Restrict);
                })
                .Annotation("MySQL:Charset", "utf8mb4");

            migrationBuilder.CreateIndex(
                name: "IX_produto_categoria_id",
                table: "produto",
                column: "categoria_id",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "produto");
        }
    }
}
