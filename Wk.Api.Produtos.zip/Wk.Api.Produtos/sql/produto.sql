CREATE DATABASE IF NOT EXISTS wk_technology;

use wk_technology;

CREATE USER 'root'@'%' IDENTIFIED BY '123456';
GRANT CREATE TEMPORARY TABLES, INSERT, UPDATE, DELETE, SELECT, DROP on wk_technology.* TO 'root'@'%' WITH GRANT OPTION;
GRANT ALL ON *.* TO 'root'@'%' WITH GRANT OPTION;

CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
    `MigrationId` varchar(150) NOT NULL,
    `ProductVersion` varchar(32) NOT NULL,
    PRIMARY KEY (`MigrationId`)
);

START TRANSACTION;

CREATE TABLE `produto` (
    `produto_id` int NOT NULL AUTO_INCREMENT,
    `categoria_id` int NOT NULL,
    `produto_nome` longtext NOT NULL,
    `produto_preco` decimal(16,2) NOT NULL,
    `produto_peso` decimal(16,2) NOT NULL,
    `produto_cor` longtext NOT NULL,
    `produto_modelo` longtext NOT NULL,
    `produto_marca` longtext NOT NULL,
    PRIMARY KEY (`produto_id`),
    CONSTRAINT `FK_produto_categoria_categoria_id` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`categoria_id`) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX `IX_produto_categoria_id` ON `produto` (`categoria_id`);

INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
VALUES ('20230530024253_add_table_produto', '7.0.5');

COMMIT;

