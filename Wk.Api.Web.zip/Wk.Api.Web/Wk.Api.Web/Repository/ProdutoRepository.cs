﻿using AspnCrudDapper.Entities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace AspnCrudDapper.Repository
{
    public class ProdutoRepository : IProdutoRepository
    {
        IConfiguration _configuration;

        public ProdutoRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetConnection()
        {
            var connection = _configuration.GetSection("ConnectionStrings").GetSection("ProdutoConnection").Value;
            return connection;
        }

        public int Add(Produto produto)
        {
            using HttpClient httpClient = new();
            httpClient.Timeout = TimeSpan.FromSeconds(10);

            produto.CategoriaId = 10;

            StringContent json = new(
                content: JsonConvert.SerializeObject(produto),
                encoding: Encoding.UTF8,
                mediaType: "application/json");

            HttpResponseMessage result = httpClient.PostAsync(
                    "http://localhost:52130/api/Produto",
                    json
                ).Result;

            return 1;
        }

        public int Delete(int id)
        {
            using HttpClient httpClient = new();
            httpClient.Timeout = TimeSpan.FromSeconds(10);

            HttpResponseMessage result = httpClient.DeleteAsync(
                 $"http://localhost:52130/api/Produto/{id}"
             ).Result;

            return 1;
        }

        public int Edit(Produto produto)
        {
            using HttpClient httpClient = new();
            httpClient.Timeout = TimeSpan.FromSeconds(10);

            produto.CategoriaId = 10;

            StringContent json = new(
                content: JsonConvert.SerializeObject(produto),
                encoding: Encoding.UTF8,
                mediaType: "application/json");

            HttpResponseMessage result = httpClient.PutAsync(
                    "http://localhost:52130/api/Produto",
                    json
                ).Result;

            return 1;
        }

        public Produto Get(int id)
        {
            using HttpClient httpClient = new();
            httpClient.Timeout = TimeSpan.FromSeconds(10);

            HttpResponseMessage result = httpClient.GetAsync(
                 $"http://localhost:52130/api/Produto/{id}"
             ).Result;

            Produto produto =
                JsonConvert.DeserializeObject<Produto>(result.Content.ReadAsStringAsync().Result);

            return produto;
        }

        public List<Produto> GetProdutos()
        {
            using HttpClient httpClient = new();
            httpClient.Timeout = TimeSpan.FromSeconds(10);

            HttpResponseMessage result = httpClient.GetAsync(
                 "http://localhost:52130/api/Produto"
             ).Result;

            IEnumerable<Produto> produtos =
                JsonConvert.DeserializeObject<IEnumerable<Produto>>(result.Content.ReadAsStringAsync().Result);

            return produtos.ToList();
        }
    }
}
