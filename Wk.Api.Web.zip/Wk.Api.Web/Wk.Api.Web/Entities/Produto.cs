﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AspnCrudDapper.Entities
{
    public class Produto
    {
        [Key]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Nome do Produto")]
        [StringLength(25, ErrorMessage = "O nome deve ter entre 1 até 100 caracteres")]
        public string Nome { get; set; }

        [Required]
        [Display(Name = "Preço")]
        public decimal Preco { get; set; }

        [Required]
        [Display(Name = "Peso")]
        [Range(1, Int32.MaxValue, ErrorMessage = "Valor deve ser maior ou igual a 1")]
        public decimal Peso { get; set; }

        [Required]
        [Display(Name = "Cor")]
        public string Cor { get; set; }

        [Required]
        [Display(Name = "Modelo")]
        public string Modelo { get; set; }

        [Required]
        [Display(Name = "Marca")]
        public string Marca { get; set; }

        public int CategoriaId { get; set; }
    }
}
