CREATE DATABASE IF NOT EXISTS wk_technology;

use wk_technology;

CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
    `MigrationId` varchar(150) NOT NULL,
    `ProductVersion` varchar(32) NOT NULL,
    PRIMARY KEY (`MigrationId`)
);

START TRANSACTION;

CREATE TABLE `categoria` (
    `categoria_id` int NOT NULL AUTO_INCREMENT,
    `categoria_descricao` longtext NOT NULL,
    PRIMARY KEY (`categoria_id`)
);

INSERT INTO
    `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
VALUES
    ('20230530021537_add_table_categoria', '7.0.5');

COMMIT;

INSERT INTO
    `categoria`
VALUES
    (1, 'servi�os digitais'),
    (2, 'perfumaria e cosm�ticos'),
    (3, 'alimentos e bebidas'),
    (4, 'casa e decora��o'),
    (5, 'sa�de e bem-estar'),
    (6, 'utens�lios dom�sticos'),
    (7, 'm�dia'),
    (8, 'produtos para pets'),
    (9, 'equipamentos de escrit�rio');