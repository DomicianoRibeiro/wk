using Microsoft.AspNetCore.Mvc;
using Wk.Api.Categorias.Domain.Entities;
using Wk.Api.Categorias.Domain.Interfaces.Services;

namespace Wk.Api.Categorias
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]

    public class CategoriaController : BaseController<Categoria>
    {
        private readonly ICategoriaServico _produtoServico;

        public CategoriaController(ICategoriaServico produtoServico) : base(produtoServico)
        {
            _produtoServico = produtoServico;
        }
    }
}
