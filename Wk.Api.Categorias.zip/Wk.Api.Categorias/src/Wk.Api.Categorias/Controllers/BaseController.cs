﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Wk.Api.Categorias.Domain.Entities;
using Wk.Api.Categorias.Domain.Interfaces.Services;

namespace Wk.Api.Categorias
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController<T> : Controller where T : BaseEntidade
    {
        protected readonly IBaseServico<T> _baseServico;

        public BaseController(IBaseServico<T> baseServico)
        {
            _baseServico = baseServico;
        }

        [HttpGet]
        [Route("")]
        public virtual async Task<IActionResult> Listar()
        {
            var list = await _baseServico.BuscarTodos();
            return new OkObjectResult(list);
        }

        [HttpGet]
        [Route("{id}")]
        public virtual async Task<IActionResult> SelecionarPorId(int id)
        {
            var objById = await _baseServico.BuscarPorId(id);
            return new OkObjectResult(objById);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Incluir([FromBody] T entidade)
        {
            await _baseServico.Incluir(entidade);
            return Ok();
        }

        [HttpPut]
        public virtual async Task<IActionResult> Alterar([FromBody] T entidade)
        {
            await _baseServico.Alterar(entidade);
            return new OkObjectResult(true);
        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            await _baseServico.Excluir(id);
            return new OkObjectResult(true);
        }
    }
}
