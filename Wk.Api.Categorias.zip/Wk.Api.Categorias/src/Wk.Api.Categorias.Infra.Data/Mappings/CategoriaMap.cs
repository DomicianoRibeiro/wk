﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Wk.Api.Categorias.Domain.Entities;

namespace Wk.Api.Categorias.Infra.Data.Mappings
{
    public class CategoriaMap : IEntityTypeConfiguration<Categoria>
    {
        public void Configure(EntityTypeBuilder<Categoria> builder)
        {
            builder.ToTable("categoria");

            builder.HasKey(s => s.Id);

            builder
                .Property(c => c.Id)
                .ValueGeneratedOnAdd()
                .IsRequired()
                .HasColumnName("categoria_id");

            builder
            .Property(c => c.Descricao)
            .HasColumnName("categoria_descricao")
            .IsRequired();
        }
    }
}
