﻿using Wk.Api.Categorias.Domain.Entities;
using Wk.Api.Categorias.Domain.Interfaces.Repositories;
using Wk.Api.Categorias.Infra.Data.Contexto;

namespace Wk.Api.Categorias.Infra.Data.Repositories
{
    public class CategoriaRepositorio : BaseRepositorio<Categoria>, ICategoriaRepositorio
    {
        public CategoriaRepositorio(BaseContexto context) : base(context)
        {
        }
    }
}
