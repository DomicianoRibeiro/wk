﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Wk.Api.Categorias.Domain.Entities;
using Wk.Api.Categorias.Domain.Interfaces.Repositories;
using Wk.Api.Categorias.Infra.Data.Contexto;

namespace Wk.Api.Categorias.Infra.Data.Repositories
{

    public class BaseRepositorio<T> : IBaseRepositorio<T> where T : BaseEntidade
    {
        protected readonly BaseContexto _context;
        protected readonly DbSet<T> _dbSet;
        public BaseRepositorio(BaseContexto context)
        {
            _context = context;
            _dbSet = context.Set<T>();
        }

        #region Leitura

        public async Task<T> BuscarPorId(object id, string[] includes = default, bool tracking = false)
        {
            return await _dbSet.FindAsync(id);
        }

        public async Task<T> BuscarComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false)
        {
            return await Buscar(expression, includes, tracking).FirstOrDefaultAsync();
        }

        public IQueryable<T> Buscar(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false)
        {
            IQueryable<T> query = _dbSet.Where(expression);
            if (!tracking)
                query = query.AsNoTracking();
            if (includes != null)
                foreach (string property in includes)
                    query = query.Include(property);
            return query;
        }

        public async Task<IEnumerable<T>> BuscarTodos(string[] includes = default, bool tracking = false)
        {
            return await Buscar(x => true, includes, tracking).ToListAsync();
        }

        public async Task<IEnumerable<T>> BuscarTodosComPesquisa(Expression<Func<T, bool>> expression, string[] includes = default, bool tracking = false)
        {
            return await Buscar(expression, includes, tracking).ToListAsync();
        }

        public async Task<IEnumerable<T>> BuscarPorSql(string query)
        {
            return await _dbSet.FromSqlRaw(query).AsNoTracking().ToListAsync();
        }

        #endregion

        #region Escrita

        public virtual async Task<T> Incluir(T entidade)
        {
            EntityEntry<T> obj = await _dbSet.AddAsync(entidade);
            return obj.Entity;
        }

        public virtual async Task IncluirLista(List<T> entidade)
        {
            await _dbSet.AddRangeAsync(entidade);
        }

        public virtual T Alterar(T entidade)
        {
            _context.Entry(entidade).State = EntityState.Modified;
            return entidade;
        }

        public void AlterarLista(IEnumerable<T> entidades)
        {
            foreach (T entidade in entidades)
            {
                _context.Entry(entidade).State = EntityState.Modified;
            }
        }

        public async Task<bool> Excluir(object id)
        {
            try
            {
                T entidade = await BuscarPorId(id);
                if (entidade != null)
                {
                    _dbSet.Remove(entidade);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<int> ExecutarQuery(string query)
        {
            return await _context.Database.ExecuteSqlRawAsync(query);
        }

        #endregion

        public async Task IniciarTransaction()
        {
            await _context.IniciarTransaction();
        }

        public async Task SalvarMudancas(bool commit = true)
        {
            await _context.SalvarMudancas(commit);
        }

        public async Task RollbackTransaction()
        {
            await _context.RollBack();
        }

        public async Task Commit()
        {
            await _context.Commit();
        }
    }
}
