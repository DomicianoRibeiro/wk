﻿using Wk.Api.Categorias.Domain.Entities;
using Wk.Api.Categorias.Domain.Interfaces.Repositories;
using Wk.Api.Categorias.Domain.Interfaces.Services;

namespace Wk.Api.Categorias.Domain.Services
{
    public class CategoriaServico : BaseServico<Categoria>, ICategoriaServico
    {
        public CategoriaServico(ICategoriaRepositorio CategoriaRepositorio) : base(CategoriaRepositorio)
        {
        }
    }
}
