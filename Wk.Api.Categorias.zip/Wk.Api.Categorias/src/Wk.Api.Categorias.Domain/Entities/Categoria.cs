﻿namespace Wk.Api.Categorias.Domain.Entities;

public class Categoria : BaseEntidade
{
    public string Descricao { get; set; }
}