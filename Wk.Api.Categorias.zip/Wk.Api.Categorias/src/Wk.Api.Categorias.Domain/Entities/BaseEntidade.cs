﻿namespace Wk.Api.Categorias.Domain.Entities
{
    public abstract class BaseEntidade
    {
        public int Id { get; set; }
    }
}
