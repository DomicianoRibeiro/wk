﻿using Wk.Api.Categorias.Domain.Entities;

namespace Wk.Api.Categorias.Domain.Interfaces.Services
{
    public interface ICategoriaServico : IBaseServico<Categoria>
    {
    }
}
