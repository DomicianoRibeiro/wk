﻿using Wk.Api.Categorias.Domain.Entities;

namespace Wk.Api.Categorias.Domain.Interfaces.Repositories
{
    public interface ICategoriaRepositorio : IBaseRepositorio<Categoria>
    {
    }
}
