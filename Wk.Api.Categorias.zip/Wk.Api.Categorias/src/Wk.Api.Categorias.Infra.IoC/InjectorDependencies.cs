﻿using Microsoft.Extensions.DependencyInjection;
using Wk.Api.Categorias.Domain.Interfaces.Repositories;
using Wk.Api.Categorias.Domain.Interfaces.Services;
using Wk.Api.Categorias.Domain.Services;
using Wk.Api.Categorias.Infra.Data.Repositories;

namespace Wk.Api.Categorias.Infra.IoC
{
    public static class InjectorDependencies
    {
        public static void Registrer(IServiceCollection services)
        {
            //Domínio 
            services.AddScoped(typeof(IBaseServico<>), typeof(BaseServico<>));
            services.AddScoped<ICategoriaServico, CategoriaServico>();

            //Repositorio
            services.AddScoped(typeof(IBaseRepositorio<>), typeof(BaseRepositorio<>));
            services.AddScoped<ICategoriaRepositorio, CategoriaRepositorio>();
        }
    }
}
